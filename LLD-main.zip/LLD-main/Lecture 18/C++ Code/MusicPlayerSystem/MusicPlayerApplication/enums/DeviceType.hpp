#pragma once

enum class DeviceType { 
    BLUETOOTH, 
    WIRED,
    HEADPHONES 
};