package MusicPlayerApplication.external;


public class WiredSpeakerAPI {
    public void playSoundViaCable(String data) {
        System.out.println("[WiredSpeaker] Playing: " + data);
        // mimics playing music
    }
}
