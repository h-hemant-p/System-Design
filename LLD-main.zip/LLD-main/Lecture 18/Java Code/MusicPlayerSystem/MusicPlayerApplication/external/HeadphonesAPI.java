package MusicPlayerApplication.external;

public class HeadphonesAPI {
    public void playSoundViaJack(String data) {
        System.out.println("[Headphones] Playing: " + data);
        // mimics playing music
    }
}
