package MusicPlayerApplication.enums;


public enum DeviceType {
    BLUETOOTH,
    WIRED,
    HEADPHONES
}
