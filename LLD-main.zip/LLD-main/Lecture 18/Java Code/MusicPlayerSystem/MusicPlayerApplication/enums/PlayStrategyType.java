package MusicPlayerApplication.enums;


public enum PlayStrategyType {
    SEQUENTIAL,
    RANDOM,
    CUSTOM_QUEUE
}
